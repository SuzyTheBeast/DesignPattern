package factory;

public class ProduitA2 extends ProduitA {
	
	public void methodeA() {
		System.out.println("Je suis un produit de type A1");
		System.out.println("ProduitA1.methodeA()");
	}
}
