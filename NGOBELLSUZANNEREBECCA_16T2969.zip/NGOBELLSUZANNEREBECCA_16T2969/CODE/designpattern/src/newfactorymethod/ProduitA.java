package newfactorymethod;

public abstract class ProduitA {
	public abstract void methodeA();
}

