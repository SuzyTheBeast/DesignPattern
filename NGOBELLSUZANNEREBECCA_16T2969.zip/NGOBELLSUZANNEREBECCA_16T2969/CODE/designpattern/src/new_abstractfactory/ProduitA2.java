package new_abstractfactory;

public class ProduitA2 extends ProduitA {
	
	public void methodA() {
		System.out.println("ProduitA2.methodeA(");
		
	}
}
