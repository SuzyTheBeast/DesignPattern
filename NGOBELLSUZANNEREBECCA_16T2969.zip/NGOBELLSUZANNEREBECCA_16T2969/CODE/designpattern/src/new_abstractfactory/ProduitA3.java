package new_abstractfactory;

public class ProduitA3 extends ProduitA {
	public void methodA() {
		System.out.println("ProduitA3.methodeA(");
		
	}
}

