package new_abstractfactory;

public class ProduitC2 extends ProduitC {
	public void methodC() {
		System.out.println("ProduitC2.methodeC()");
		
	}
}
