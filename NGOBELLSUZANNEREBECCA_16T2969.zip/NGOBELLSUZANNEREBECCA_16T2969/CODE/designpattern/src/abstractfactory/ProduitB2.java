package abstractfactory;

public class ProduitB2 extends ProduitB {
	public void methodB() {
		System.out.println("ProduitB2.methodeB(");
		
	}
}
