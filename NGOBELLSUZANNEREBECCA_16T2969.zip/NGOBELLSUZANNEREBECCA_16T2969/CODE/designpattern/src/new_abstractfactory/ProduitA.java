package new_abstractfactory;

public abstract class ProduitA {
	public abstract void methodA();
}
