package new_factory;

public class ProduitFactory3 extends ProduitFactory {
	
	protected ProduitA createProduitA() {
		return new ProduitA3();
	}
}
