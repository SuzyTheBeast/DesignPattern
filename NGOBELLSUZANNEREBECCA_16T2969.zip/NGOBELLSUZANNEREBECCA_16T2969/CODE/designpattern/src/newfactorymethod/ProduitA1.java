package newfactorymethod;

public class ProduitA1 extends ProduitA {
	
	public void methodeA() {
		System.out.println("Je suis un produit de type A1");
		System.out.println("ProduitA1.methodeA()");
	}
}