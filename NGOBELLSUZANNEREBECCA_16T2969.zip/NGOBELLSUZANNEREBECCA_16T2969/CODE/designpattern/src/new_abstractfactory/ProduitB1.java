package new_abstractfactory;

public class ProduitB1 extends ProduitB {
	public void methodB() {
		System.out.println("ProduitB1.methodeB(");
		
	}
}