package factory;

public abstract class ProduitA {
	public abstract void methodeA();
}
