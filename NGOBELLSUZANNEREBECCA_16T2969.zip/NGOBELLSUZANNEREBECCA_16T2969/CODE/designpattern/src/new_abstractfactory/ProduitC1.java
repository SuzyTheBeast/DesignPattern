package new_abstractfactory;

public class ProduitC1 extends ProduitC {
	public void methodC() {
		System.out.println("ProduitC1.methodeC()");
		
	}
}
