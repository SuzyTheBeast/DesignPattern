package abstractfactory;

public class ProduitA1 extends ProduitA {
	public void methodA() {
		System.out.println("ProduitA1.methodeA(");
		
	}
}
