package factorymethod;

public class ProduitA2 extends ProduitA {

	@Override
	public void methodeA() {
		System.out.println("Je suis un produit de type A2");
		System.out.println("ProduitA2.methodeA()");
		
	}

}
