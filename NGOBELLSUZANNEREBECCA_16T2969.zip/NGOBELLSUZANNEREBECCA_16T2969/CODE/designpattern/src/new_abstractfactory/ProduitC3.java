package new_abstractfactory;

public class ProduitC3 extends ProduitC {
	public void methodC() {
		System.out.println("ProduitC3.methodeC()");
		
	}
}

