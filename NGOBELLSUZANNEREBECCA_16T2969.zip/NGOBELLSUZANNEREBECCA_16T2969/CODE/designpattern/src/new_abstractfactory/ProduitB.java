package new_abstractfactory;

public abstract class ProduitB {
	public abstract void methodB();
}
