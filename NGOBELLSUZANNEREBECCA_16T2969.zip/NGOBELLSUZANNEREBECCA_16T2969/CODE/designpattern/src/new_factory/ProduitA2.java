package new_factory;

public class ProduitA2 extends ProduitA {
	
	public void methodeA() {
		System.out.println("Je suis un produit de type A2");
		System.out.println("ProduitA2.methodeA()");
	}
}
