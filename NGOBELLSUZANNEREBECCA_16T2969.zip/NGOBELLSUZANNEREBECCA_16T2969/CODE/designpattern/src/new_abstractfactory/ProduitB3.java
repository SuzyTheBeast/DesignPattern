package new_abstractfactory;

public class ProduitB3 extends ProduitB {
	public void methodB() {
		System.out.println("ProduitB3.methodeB(");
		
	}
}
