package abstractfactory;

public abstract class ProduitB {
	public abstract void methodB();
}
