package new_abstractfactory;

public abstract class ProduitC {
	public abstract void methodC();
}

