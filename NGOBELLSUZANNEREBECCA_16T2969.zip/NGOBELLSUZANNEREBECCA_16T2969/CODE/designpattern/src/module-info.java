/**
 * 
 */
/**
 * 
 */
module designpattern {
}