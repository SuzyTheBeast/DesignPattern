package new_factory;

public class ProduitFactory1 extends ProduitFactory {

	protected ProduitA createProduitA() {
		return new ProduitA1();
	}
}